<?php

namespace Elsnertech\AjaxCrud\Controller\Index;

use Magento\Framework\App\Action\Context;
use Elsnertech\AjaxCrud\Model\FormDataFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\JsonFactory;

class Delete extends Action
{
    protected $formdataFactory;
    private $resultJsonFactory;

    public function __construct(
        Context $context,
        formdataFactory $formdataFactory,
        jsonFactory $resultJsonFactory,
        RequestInterface $request
    ) {
        $this->formdataFactory = $formdataFactory;
        parent::__construct($context);
        $this->request = $request;
        $this->resultJsonFactory = $resultJsonFactory;
    }

    public function execute()
    {
            $response = [];
            $data = (array)$this->getRequest()->getParams();
        if (isset($data['id'])) {
            $model = $this->formdataFactory->create()->load($data['id']);
            $model->delete();
            $this->messageManager->addSuccessMessage(__("Record Delete Successfully."));
            $response['success'] = true;
        } else {
            $this->messageManager->addErrorMessage(__('Data was not Delete.'));
            $response['success'] = false;
        }

        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($response);
    }
}
