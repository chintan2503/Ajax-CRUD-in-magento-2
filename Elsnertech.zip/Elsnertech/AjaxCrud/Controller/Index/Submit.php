<?php

namespace Elsnertech\AjaxCrud\Controller\Index;

use Magento\Framework\App\Action\Context;
use Elsnertech\AjaxCrud\Model\FormDataFactory;
use Magento\Framework\Controller\Result\JsonFactory;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;
use Magento\Framework\Filesystem;

class Submit extends \Magento\Framework\App\Action\Action
{
    /**
     * @var save
     */
    protected $_save;
    private $resultJsonFactory;
 
    protected $uploaderFactory;
    protected $adapterFactory;
    protected $filesystem;

    public function __construct(
        Context $context,
        FormDataFactory $save,
        JsonFactory $resultJsonFactory,
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem
    ) {
        $this->_save = $save;
        $this->resultJsonFactory = $resultJsonFactory;

        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        parent::__construct($context);
    }
    public function execute()
    {

        $response = [];
        $data = $this->getRequest()->getParams();

        if (isset($_FILES['image']['name']) && $_FILES['image']['name'] != '') {
            try {
                $uploaderFactories = $this->uploaderFactory->create(['fileId' => 'image']);
                $uploaderFactories->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                $imageAdapter = $this->adapterFactory->create();
                $uploaderFactories->addValidateCallback('custom_image_upload', $imageAdapter, 'validateUploadFile');
                $uploaderFactories->setAllowRenameFiles(true);
                $uploaderFactories->setFilesDispersion(true);
                $mediaDirectory = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA);
                $destinationPath = $mediaDirectory->getAbsolutePath('elsnertech/ajaxcrud');
                $result = $uploaderFactories->save($destinationPath);
                if (!$result) {
                    throw new LocalizedException(
                        __('File cannot be saved to path: $1', $destinationPath)
                    );
                }

                $imagePath = 'elsnertech/ajaxcrud'.$result['file'];
                $data['image'] = $imagePath;
            } catch (\Exception $e) {
                
                 $e->getMessage();
                 return $e;
            }
        }

        $save = $this->_save->create();
        $save->setData($data);

        if ($save->save()) {

            $response['success'] = true;
            //$this->messageManager->addSuccessMessage(__($test['fname']. ' ! You saved the data.'));
            //$this->messageManager->addSuccessMessage(__('You saved the data.'));
            //$res = TRUE; //echo "1";
        } else {
            //$this->messageManager->addErrorMessage(__('Data was not saved.'));
            //$res = FALSE; //echo "0";
            $response['success'] = false;

        }

        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($response);
    }
}
