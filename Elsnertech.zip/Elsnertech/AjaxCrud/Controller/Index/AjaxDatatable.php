<?php

namespace Elsnertech\AjaxCrud\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;

class AjaxDatatable extends Action
{
    protected $_resultPageFactory;
    protected $_resultJsonFactory;
    protected $_showdataBlock;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
        $this->_resultJsonFactory = $resultJsonFactory;
    }

    public function execute()
    {
        $result = $this->_resultJsonFactory->create();
        $resultPage = $this->_resultPageFactory->create();
       
        $blockHtml = $resultPage->getLayout()
        ->createBlock('Elsnertech\AjaxCrud\Block\AjaxDatatable')
        ->setTemplate('Elsnertech_AjaxCrud::AjaxDatatable.phtml')
        ->toHtml();
        $result->setData(['output' => $blockHtml]);
        
        return $result;
    }
}
