<?php

namespace Elsnertech\AjaxCrud\Block;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\View\Element\Template;
use Elsnertech\AjaxCrud\Model\FormDataFactory;

class CustomForm extends Template
{
    private $formdataFactory;
   
    public function __construct(FormDataFactory $formdataFactory, Context $context, array $data = [])
    {
        parent::__construct($context, $data);
        $this->formdataFactory = $formdataFactory;
    }

    public function getFormAction()
    {
        return $this->getUrl('ajaxcrud/index/submit');
    }

    public function getAllData()
    {
        $id = $this->getRequest()->getParam("id");
        $model = $this->formdataFactory->create();
        return $model->load($id);
    }
}
