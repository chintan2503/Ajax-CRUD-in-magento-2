require(['jquery'], function () {
    jQuery(document).ready(function () {
        listing();
        jQuery("#addData").submit(function () {

            var name = jQuery("input[name='iname']").val();
            var city = jQuery("input[name='icity']").val();
            // var image = jQuery("input[name='image']").val();

            var formData = new FormData(this);
            formData.append('name', name);
            formData.append('city', city);


            var image = document.getElementById("image");
            formData.append('image', image.files[0]);

            alert(image);
            alert(name);
            var url = 'ajaxcrud/index/save';
            jQuery.ajax({
                url: url,
                type: "POST",
                // data: {name:name,city:city,image:image},
                data: formData,
                enctype: 'multipart/form-data',
                dataType: "JSON",
                contentType: false,
                processData: false,
                showLoader: false,
                cacheable: false,
                success: function (response) {
                    jQuery('#add-form-block').hide();
                    jQuery('.data-listing-block').show();
                    listing();
                }
            });
            return false;
            e.preventDefault();
        });

        jQuery(document).on('click','.add_new',function () {

            jQuery('.data-listing-block').hide();
            jQuery('#add-form-block').show();

        });


        jQuery(document).on('click','.deletes',function () {
            alert("hello i am chintan");
            console.log("Hello I am Chintan");
            var id = jQuery(this).attr('id');
            alert("Are You Sure To Delete Data ?");
            alert(id);

            var url = 'ajaxcrud/index/delete';
            jQuery.ajax({
                url: url,
                type: "POST",
                data: { id: id },
                showLoader: false,
                cacheable: false,
                success: function (response) {
                    // console.log(response.success);
                    listing();

                }
            });
            return false;
            e.preventDefault();
        });


        // Fro Load Data In Form--------------------------------------------------------------------------

        jQuery(document).on('click','.edits', function () {

            var id = jQuery(this).attr('id');
            var edit_name = jQuery(this).attr('edit_name');
            var edit_city = jQuery(this).attr('edit_city');
            //  var image = jQuery(this).attr('edit_image');

            jQuery.ajax({
                type: "POST",
                success: function (response) {
                    jQuery("#id").val(id);
                    jQuery("#name").val(edit_name);
                    jQuery("#city").val(edit_city);
                    //  jQuery("#image").val(image);
                }
            });
            return false;
            e.preventDefault();
        });


        // For Update Data--------------------------------------------------------------------------
        jQuery(document).on('click','#sub', function () {

            var id = jQuery("input[name='id']").val();
            var name = jQuery("input[name='name']").val();
            var city = jQuery("input[name='city']").val();
            // var image = jQuery("input[name='image']").val();


            var url = 'ajaxcrud/index/submit';
            jQuery.ajax({
                url: url,
                type: "POST",
                data: { id: id, name: name, city: city },
                showLoader: false,
                cacheable: false,
                success: function (response) {
                    console.log(response.success);
                    listing();
                    alert("Data Update !!!!");
                    jQuery('#add-form-block').hide();
                    jQuery('.data-listing-block').show();

                }
            });
            return false;
            e.preventDefault();
        });

        //----- For Listing ----

        function listing() {
            var url = 'ajaxcrud/index/ajaxdatatable';
            jQuery.ajax({
                url: url,
                type: "POST",
                data: {},
                showLoader: false,
                cacheable: false,
                success: function (response) {
                    console.log(response.output);
                    jQuery('.data-listing-block').html(response.output);
                }
            });
        }


    });
});