<?php
namespace Elsnertech\AjaxCrud\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class FormData extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('elsner_ajax_demo', 'id');
    }
}
