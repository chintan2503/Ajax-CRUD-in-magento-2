<?php
namespace Elsnertech\AjaxCrud\Model\ResourceModel\FormData;

use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(
            'Elsnertech\AjaxCrud\Model\FormData',
            'Elsnertech\AjaxCrud\Model\ResourceModel\FormData'
        );
    }
}
