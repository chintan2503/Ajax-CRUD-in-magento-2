<?php

namespace Elsnertech\AjaxCrud\Model;

use Magento\Framework\Model\AbstractModel;

class FormData extends AbstractModel
{
    protected function _construct()
    {
        $this->_init('Elsnertech\AjaxCrud\Model\ResourceModel\FormData');
    }
}
